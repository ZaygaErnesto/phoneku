<div class="bg-gray-50 min-h-screen py-8">
      <main class="container mx-auto px-4">
          <h1 class="text-2xl font-bold text-yellow-600">Pembayaran Menunggu Konfirmasi</h1>
          <p>Kode pesanan: {{ request('order_id') }}. Silakan lakukan pembayaran segera.</p>
      </main>
  </div>